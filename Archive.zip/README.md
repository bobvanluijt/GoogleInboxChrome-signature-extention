GoogleInboxChrome-signature-extention
=====================================

Chrome extention for HTML signatures in Googe Inbox

## How it works:
1) Download the Google Chrome extention in the plugin (search https://chrome.google.com/webstore/category/extensions?hl=en-US)<br>
2) Enjoy :-)

![How it works](https://raw.githubusercontent.com/kubrickology/GoogleInboxChrome-signature-extention/master/screenshot.png)
